# FurbabaDev Support page

1. Open `index.html` in a text editor.
2. Only after confirming with your parent/guardian and Ziraat Bank that the account may be used for this purpose, replace the IBAN placeholder.
3. Ask Ziraat which exact SWIFT/BIC and recipient details are required for international transfers. Do not assume the placeholder is sufficient.
4. Publish the folder using GitHub Pages, then add the public page URL to Modrinth > Donation Links > Other.

Do not put card number, expiry date, CVV, online banking password, or identity documents on this page.
